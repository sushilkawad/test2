import { Component, OnInit } from '@angular/core';
import { RocketService } from '../../shared/services/rocket.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})

export class UsersComponent implements OnInit {
  users = [];

  constructor(private rocketService:RocketService,private router: Router) { }

  ngOnInit() {
    this.users = this.rocketService.getAllUsers();
  }

  onSelect(id){
    this.router.navigate(['/users',id]);
  }
}
